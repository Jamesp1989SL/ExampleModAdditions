package examplemod.examples.Objects;

import necesse.level.gameObject.RockObject;
import necesse.level.gameObject.RockOreObject;

import java.awt.Color;

/**
 * Example ore rock that uses our ExampleIncursionDeepRockObject as its parent rock.
 */
public class ExampleOreRockObject extends RockOreObject {

    public static final String ID = "exampleorerock";

    public ExampleOreRockObject(RockObject parentRock) {
        super(
                parentRock,
                "oremask",
                "exampleore",
                new Color(90, 40, 160),
                "exampleore",
                1,
                3,
                2,
                true,
                new String[]{"objects", "landscaping"}
        );
    }
}

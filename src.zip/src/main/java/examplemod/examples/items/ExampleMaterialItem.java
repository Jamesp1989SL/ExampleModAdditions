package examplemod.examples.items;

import necesse.inventory.item.matItem.MatItem;

public class ExampleMaterialItem extends MatItem {

    public ExampleMaterialItem() {
        super(100, Rarity.UNCOMMON);
    }

}

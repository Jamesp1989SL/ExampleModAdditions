package examplemod.examples.items;

import necesse.inventory.item.matItem.MatItem;

public class ExampleHuntIncursionMaterialItem extends MatItem {

    public ExampleHuntIncursionMaterialItem() {
        super(100, Rarity.RARE);
    }

}
